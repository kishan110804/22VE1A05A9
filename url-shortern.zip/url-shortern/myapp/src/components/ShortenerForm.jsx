import React, {useState} from 'react';
import {TextField,Button,Box,Typography} from '@mui/material';
import {logRequest} from "../middleware/logger.js";
import {generateShortCode} from '../utils/urlutils';

const ShortenerForm = ({ onShorten }) => {
    const [longUrl, setLongUrl] = useState('');
    const [expiry, setExpiry] = useState('');
    const [customCode, setCustomCode] = useState('');

    const handleSubmit = (e) => {
    e.preventDefault();
    if (!longUrl.trim()) {
        alert("Please enter a valid URL");
        return;
    }

    const shortCode = customCode || generateShortCode();
    const validTime = expiry ? parseInt(expiry) : 30;

    const newEntry = {
        shortCode,
        longUrl,
        createdAt: Date.now(),
        expiresAt: Date.now() + validTime * 60 * 1000,
        clicks: [],
    };

    logRequest("URL Shortened", newEntry);
    onShorten(newEntry);
    };

    return (
    <Box sx={{ p: 3 }}>
        <Typography variant="h5">Shorten a URL</Typography>
        <form onSubmit={handleSubmit}>
        <TextField label="Long URL" fullWidth sx={{ my: 1 }} value={longUrl} onChange={(e) => setLongUrl(e.target.value)} />
        <TextField label="Custom Shortcode (optional)" fullWidth sx={{ my: 1 }} value={customCode} onChange={(e) => setCustomCode(e.target.value)} />
        <TextField label="Expiry (minutes, optional)" fullWidth sx={{ my: 1 }} value={expiry} onChange={(e) => setExpiry(e.target.value)} />
        <Button type="submit" variant="contained">Shorten</Button>
        </form>
    </Box>
    );
};

export default ShortenerForm;
