import { useParams, useNavigate } from "react-router-dom";
import { useEffect } from "react";

const RedirectHandler = () => {
    const { shortcode } = useParams();
    const navigate = useNavigate();

    useEffect(() => {
    const logs = JSON.parse(localStorage.getItem("logs") || "[]");
    const match = logs.find(l => l.data.shortCode === shortcode);

    if (!match) {
        alert("Shortcode not found!");
        return navigate("/");
    }

    const now = Date.now();
    if (now > match.data.expiresAt) {
        alert("Link expired!");
        return navigate("/");
    }

    // Log the click
    match.data.clicks.push({
        time: new Date().toISOString(),
        referrer: document.referrer || "Direct",
      location: "India", // Placeholder
    });

    localStorage.setItem("logs", JSON.stringify(logs));
    window.location.href = match.data.longUrl;
    }, [shortcode]);

    return null;
};

export default RedirectHandler;
