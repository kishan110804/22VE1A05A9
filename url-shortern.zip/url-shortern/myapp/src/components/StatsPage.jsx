import React from "react";
import { Typography, Box, List, ListItem, Divider } from "@mui/material";

const StatsPage = () => {
    const logs = JSON.parse(localStorage.getItem("logs") || "[]");

    return (
    <Box sx={{ p: 3 }}>
        <Typography variant="h5" sx={{ mb: 2 }}>
        Click Statistics
        </Typography>
        <List>
        {logs.map((log, index) => (
            <React.Fragment key={index}>
            <ListItem>
                <Box>
                <strong>Time:</strong> {log.timestamp}
                <br />
                <strong>Short Code:</strong> {log.data.shortCode}
                <br />
                <strong>Clicks:</strong> {log.data.clicks?.length || 0}
                </Box>
            </ListItem>
            <Divider />
            </React.Fragment>
        ))}
        </List>
    </Box>
    );
};

export default StatsPage;
