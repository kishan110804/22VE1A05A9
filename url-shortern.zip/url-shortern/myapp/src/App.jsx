import React, { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import ShortenerForm from './components/ShortenerForm';
import StatsPage from './components/StatsPage';
import RedirectHandler from './components/RedirectHandler';

function App() {
  const [urls, setUrls] = useState([]);

  const handleNewShortUrl = (urlData) => {
    setUrls(prev => [...prev, urlData]);
  };

  return (
    <Routes>
      <Route path="/" element={<ShortenerForm onShorten={handleNewShortUrl} />} />
      <Route path="/stats" element={<StatsPage />} />
      <Route path="/:shortcode" element={<RedirectHandler />} />
    </Routes>
  );
}

export default App;
